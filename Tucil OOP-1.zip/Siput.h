#ifndef SIPUT_H
#define SIPUT_H

#define SpeedSiput 2;

#include "Benda.h"
#include "LinkedList.h"
class Koin;
class Guppy;
class Piranha;
class MakananIkan;

#include <iostream>

using namespace std;

class Siput : public Benda {
public:
	Siput(int,int); //x,y Panggil Benda(x,y,SpeedSnail)
  	~Siput();


  	void move();
  	//Inisiasi nextTurn untuk siput
  	void nextTurn(LinkedList<Guppy>&, LinkedList<Piranha>&, LinkedList<MakananIkan>&, LinkedList<Koin>&, Siput&);
  	//Menghasilkan Koin terdekat secara jarak dari siput
  	Koin getKoinTerdekat(const LinkedList<Koin> &listKoin) const;
	//Siput bergerak kearah Koin terdekat lalu mengambil Koin bila koordinat sesuai
	void findKoin(LinkedList<Koin> &listKoin, Koin &Koin);

  	bool operator==(const Siput&);
	
};

#endif