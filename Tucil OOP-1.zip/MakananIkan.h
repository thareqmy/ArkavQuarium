#ifndef MAKANANIKAN_H
#define MAKANANIKAN_H

#include <iostream>

#include "LinkedList.h"
#include "benda.h"

class Koin;
class Guppy;
class Piranha;
class Siput;
#define MakananIkanSpeed 1


using namespace std;

class MakananIkan : public Benda {
	public :
		MakananIkan();
		MakananIkan(int); // x dengan y 0, memanggil Benda(x,0,MakananIkanSpeed)
		~MakananIkan();
		//inisiasi nextTurn MakananIkan
		void nextTurn(LinkedList<Guppy>&, LinkedList<Piranha>&, LinkedList<MakananIkan>&, LinkedList<Koin>&, Siput&);

		bool operator == (const MakananIkan&);
		
		//Untuk Move MakananIkan kebawah
		void move();
	private :
};

#endif
