#ifndef BENDA_H
#define BENDA_H

#include <iostream>

#include "LinkedList.h"

class Koin;
class Guppy;
class Piranha;
class MakananIkan;
class Siput;

using namespace std;


class Benda { 
  protected: 
    int x; 
    int y; 
    int speed; 

  public: 
    Benda(int,int,int); 
    virtual ~Benda(); 

    void setX(int); 
    void setY(int); 
    void setSpeed(int); 
    int getX() const; 
    int getY() const; 
    int getSpeed() const; 
    void moveUp(); 
    void moveDown(); 
    void moveRight(); 
    void moveLeft(); 

    virtual void move() = 0; 
    virtual void nextTurn(LinkedList<Guppy>&, LinkedList<Piranha>&, LinkedList<MakananIkan>&, LinkedList<Koin>&, Siput&) = 0;
}; 

#endif